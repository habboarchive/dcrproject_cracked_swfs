Habbo.swf
This release is RC4 patched only.
RSA keys have not been changed.

Cracked by mikkelfriis
Provided by http://dcr-project.bifi2000.net/